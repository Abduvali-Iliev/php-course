<?php $__env->startSection('content'); ?>
    <div class="container p-5 m-5 bg-secondary">
        <div class="row">
            <?php if(session('message')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(action([\App\Http\Controllers\UserController::class, 'update'],['user'=>$user])); ?>"
                  method="post" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <h1 class="text-center">Edit User</h1>
                <div class="form-group">
                    <label for="author">Name</label><br/>
                    <input class="form-control my-2" type="text" name="name" id="name" value="<?php echo e($user->name); ?>"/>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Lastname</label><br/>
                    <input class="form-control my-2" type="text" name="lastname" id="lastname" value="<?php echo e($user->lastname); ?>"/>
                    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Email</label><br/>
                    <input class="form-control my-2" type="text" name="email" id="email" value="<?php echo e($user->email); ?>"/>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Password</label><br/>
                    <input class="form-control my-2" type="text" name="password" id="password" value="<?php echo e($user->password); ?>"/>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Description</label><br/>
                    <input class="form-control my-2" type="text" name="description" id="description"
                           value="<?php echo e($user->description); ?>"/>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Url address</label><br/>
                    <input class="form-control my-2" type="text" name="url" id="url" value="<?php echo e($user->url); ?>"/>
                    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Date of birth</label><br/>
                    <input class="form-control my-2" type="text" name="dob" id="dob" value="<?php echo e($user->dob); ?>" placeholder="year-month-day"/>
                    <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <img src="<?php echo e(asset('/storage/' . $user->picture)); ?>" alt="<?php echo e($user->picture); ?>" style="width:100px;height:100px;"><br/><br>
                <div class="form-group">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFile" name="picture" value="<?php echo e($user->picture); ?>">
                        <label class="custom-file-label" for="customFile">Choose file</label>
                    </div>
                </div>

                <div class="form-group text-center">
                    <fieldset class="d-inline-block">
                        <legend class="text-info my-2">Sex</legend>
                        <input type="radio" name="sex" id="sex" value="Male"/>
                        <label for="author">Male</label><br/>
                        <input type="radio" name="sex" id="sex" value="female"/>
                        <label for="author">female</label>
                        <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>

                    <fieldset class="d-inline-block">
                        <legend class="text-info my-2">Активность</legend>
                        <input type="radio" name="user_activity" id="user_activity" value="<?php echo e($user->user_activity); ?>"/>
                        <label for="author">Активен</label><br/>
                        <input type="radio" name="user_activity" id="user_activity" value="<?php echo e($user->user_activity); ?>"/>
                        <label for="author">Неактивен</label>
                        <?php $__errorArgs = ['user_activity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>

                <div class="form-group mt-3">
                    <label for="author">State</label><br/>
                    <input class="form-control my-2" type="text" name="state" id="state" value="<?php echo e($user->state); ?>"/>
                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="d-block px-4 my-2 text-bg-dark ">Create</button>
            </form>
        </div>
        <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'index'])); ?>" class=" my-3 d-inline-block px-5 text-bg-dark">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/HW_46/resources/views/actions/edit.blade.php ENDPATH**/ ?>