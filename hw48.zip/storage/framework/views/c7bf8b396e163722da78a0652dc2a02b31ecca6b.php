<?php $__env->startSection('content'); ?>
    <div class="container p-3 bg-light">
        <h1>Users Accounting</h1>
        <p>
            <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'create'])); ?>" class="btn btn-outline-primary">
                Create Article
            </a>
        </p>

        <?php if(session('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="row">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Picture</th>
                    <th scope="col">Name</th>
                    <th scope="col">lastname</th>
                    <th scope="col">Email</th>
                    <th scope="col">Date of birth</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if(!is_null($user->picture)): ?>
                            <img src="<?php echo e(asset('storage/' . $user->picture)); ?>" alt="<?php echo e($user->picture); ?>" height="100" width="100">
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(action([\App\Http\Controllers\UserController::class, 'show'], ['user' => $user])); ?>">
                                <?php echo e($user->name); ?>

                            </a>
                        </td>
                        <td>
                            <?php echo e($user->lastname); ?>

                        </td>
                        <td>
                            <?php echo e($user->email); ?>

                        </td>
                        <td>
                            <?php echo e($user->dob); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/HW_46/resources/views/actions/index.blade.php ENDPATH**/ ?>