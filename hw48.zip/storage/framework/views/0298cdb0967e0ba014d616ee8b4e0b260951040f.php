<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
                <?php if(session('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
            <form action="<?php echo e(action([\App\Http\Controllers\UserController::class, 'store'])); ?>"
            method="post">
                <?php echo csrf_field(); ?>
                <h1>Create User</h1>
                <div class="form-group">
                    <label for="author">Name</label><br/>
                    <input class="form-control" type="text" name="name" id="name"/>
                </div>
                <div class="form-group">
                    <label for="author">Lastname</label><br/>
                    <input class="form-control" type="text" name="lastname" id="lastname"/>
                </div>
                <div class="form-group">
                    <label for="author">Email</label><br/>
                    <input class="form-control" type="text" name="email" id="email"/>
                </div>
                <div class="form-group">
                    <label for="author">Password</label><br/>
                    <input class="form-control" type="text" name="password" id="password"/>
                </div>
                <div class="form-group">
                    <label for="author">Description</label><br/>
                    <input class="form-control" type="text" name="description" id="description"/>
                </div>

                <div class="form-group m-3">
                    <fieldset>
                        <legend class="text-success">Sex</legend>
                        <input type="radio" name="sex" id="sex" value="Male"/>
                        <label for="author">Male</label><br/>
                        <input type="radio" name="sex" id="sex" value="female"/>
                        <label for="author">female</label>
                    </fieldset>
                </div>

                <div class="form-group">
                    <label for="author">State</label><br/>
                    <input class="form-control" type="text" name="state" id="state"/>
                </div>
                <div style="display: inline-block">
                    <fieldset>
                        <legend class="text-success">Активность</legend>
                        <input type="radio" name="user_activity" id="user_activity" value="true"/>
                        <label for="author">Активен</label><br/>
                        <input type="radio" name="user_activity" id="user_activity" value="false"/>
                        <label for="author">Неактивен</label>
                    </fieldset>
                </div>

                <button type="submit">Create</button>
            </form>
        </div>
        <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'index'])); ?>">Back</a>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abduvali/laravel/lessons/HW_46/resources/views/actions/create.blade.php ENDPATH**/ ?>