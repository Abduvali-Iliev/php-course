<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <h1>Name: <?php echo e($user->name); ?></h1>
        </div>
        <img src="<?php echo e(asset('storage/' . $user->picture)); ?>" alt="<?php echo e($user->picture); ?>" height="300" width="300">

        <div class="card-body">

            <p>
                <strong>Lastname: <?php echo e($user->lastname); ?> </strong>
            </p>
            <p>
                Email: <?php echo e($user->email); ?>

            </p>
            <p>Date of birthday: <?php echo e($user->dob); ?></p>
            <p>Description: <?php echo e($user->description); ?></p>
            <p>Sex: <?php echo e($user->sex); ?></p>
            <p>State: <?php echo e($user->state); ?></p>

        </div>
        <div class="container">
            <button type="submit" class="btn btn-warning " style="display: inline-block">
                <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'index'])); ?>" class="text-dark">Back</a>
            </button>
            <form style="display: inline-block"
                  action="<?php echo e(action([App\Http\Controllers\UserController::class, 'destroy'], ['user' => $user])); ?> "
                  method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">
                    Delete
                </button>
            </form>
            <button style="display: inline-block" type="submit" class="btn btn-danger">
                <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'edit'], ['user' => $user])); ?> "
                   class="text-dark">Update</a>
            </button>
        </div>


    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/HW_46/resources/views/actions/show.blade.php ENDPATH**/ ?>