<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session('message')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(action([\App\Http\Controllers\UserController::class, 'update'],['user'=>$user])); ?>"
                  method="post">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
                <h1>Edit User</h1>
                <div class="form-group">
                    <label for="author">Name</label><br/>
                    <input class="form-control" type="text" name="name" id="name" value="<?php echo e($user->name); ?>"/>
                </div>
                <div class="form-group">
                    <label for="author">Lastname</label><br/>
                    <input class="form-control" type="text" name="lastname" id="lastname" value="<?php echo e($user->lastname); ?>"/>
                </div>
                <div class="form-group">
                    <label for="author">Email</label><br/>
                    <input class="form-control" type="text" name="email" id="email" value="<?php echo e($user->email); ?>"/>
                </div>
                <div class="form-group">
                    <label for="author">Password</label><br/>
                    <input class="form-control" type="text" name="password" id="password" value="<?php echo e($user->password); ?>"/>
                </div>
                <div class="form-group">
                    <label for="author">Description</label><br/>
                    <input class="form-control" type="text" name="description" id="description"
                           value="<?php echo e($user->description); ?>"/>
                </div>
                <div class="form-group">
                    <label for="author">Sex</label><br/>
                    <input class="form-control" type="text" name="sex" id="sex" value="<?php echo e($user->sex); ?>"/>
                </div>

                <div class="form-group">
                    <label for="author">State</label><br/>
                    <input class="form-control" type="text" name="state" id="state" value="<?php echo e($user->state); ?>"/>
                </div>
                <div style="display: inline-block">
                    <fieldset>
                        <legend class="text-success">Активность</legend>
                        <input type="radio" name="user_activity" id="user_activity" value="<?php echo e($user->user_activity); ?>"/>
                        <label for="author">Активен</label><br/>
                        <input type="radio" name="user_activity" id="user_activity" value="<?php echo e($user->user_activity); ?>"/>
                        <label for="author">Неактивен</label>
                    </fieldset>
                </div>

                <button type="submit">Create</button>
            </form>
        </div>
        <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'index'])); ?>">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abduvali/laravel/lessons/HW_46/resources/views/actions/edit.blade.php ENDPATH**/ ?>