<?php $__env->startSection('content'); ?>
    <div class="container p-5 m-5 bg-light">
        <div class="row">
                <?php if(session('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
            <form action="<?php echo e(action([\App\Http\Controllers\UserController::class, 'store'])); ?>"
                        method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h1 class="text-center text-center">Create User</h1>

                <div class="form-group">
                    <label for="author">Name</label><br/>
                    <input class="form-control my-2" type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"/>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Lastname</label><br/>
                    <input class="form-control my-2" type="text" name="lastname" id="lastname" value="<?php echo e(old('lastname')); ?>"/>
                    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Email</label><br/>
                    <input class="form-control my-2" type="text" name="email" id="email" value="<?php echo e(old('email')); ?>"/>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Password</label><br/>
                    <input class="form-control my-2" type="text" name="password" id="password" value="<?php echo e(old('password')); ?>"/>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Description</label><br/>
                    <input class="form-control my-2" type="text" name="description" id="description" value="<?php echo e(old('description')); ?>"/>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Url address</label><br/>
                    <input class="form-control my-2" type="text" name="url" id="url" value="<?php echo e(old('url')); ?>"/>
                    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="author">Date</label><br/>
                    <input class="form-control my-2" type="text" name="dob" id="dob" value="<?php echo e(old('dob')); ?>" placeholder="year-month-day"/>
                    <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group my-4">
                    <div class="custom-file">
                        <label class="custom-file-label" for="customFile">Choose file</label>
                        <input type="file" class="custom-file-input form-control" id="customFile" name="picture">
                    </div>
                </div>

                <div class="form-group m-3 text-center">
                    <fieldset class="d-inline-block">
                        <legend class="text-info my-2">Sex</legend>
                        <input type="radio" name="sex" id="sex" value="Male"/>
                        <label for="author">Male</label><br/>
                        <input type="radio" name="sex" id="sex" value="female"/>
                        <label for="author">female</label>
                        <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                    <fieldset class="d-inline-block">
                        <legend class="text-info my-2">Активность</legend>
                        <input type="radio" name="user_activity" id="user_activity" value="true"/>
                        <label for="author">Активен</label><br/>
                        <input type="radio" name="user_activity" id="user_activity" value="false"/>
                        <label for="author">Неактивен</label>
                        <?php $__errorArgs = ['user_activity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </fieldset>
                </div>

                <div class="form-group mb-4">
                    <label for="author">State</label><br/>
                    <input class="form-control my-2" type="text" name="state" id="state" value="<?php echo e(old('text')); ?>"/>
                    <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="d-block px-4 my-2 text-bg-dark" >Create</button>
            </form>
        </div>
        <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'index'])); ?>" class=" my-3 d-inline-block px-5 text-bg-dark">Back</a>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/HW_46/resources/views/actions/create.blade.php ENDPATH**/ ?>