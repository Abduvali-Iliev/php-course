<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Name: <?php echo e($user->name); ?></h1>
        <p>
            <strong>Lastname: <?php echo e($user->lastname); ?> </strong>
            Email: <?php echo e($user->email); ?>

        </p>
        <p>Description: <?php echo e($user->description); ?></p>
        <p>Sex: <?php echo e($user->sex); ?></p>
        <p>State: <?php echo e($user->state); ?></p>

    </div>
    <div>
        <button type="submit" class="btn btn-warning " style="display: inline-block">
        <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'index'])); ?>" class="text-dark">Back</a>
        </button>
        <form style="display: inline-block" action="<?php echo e(action([App\Http\Controllers\UserController::class, 'destroy'], ['user' => $user])); ?> " method="post">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button  type="submit" class="btn btn-primary" >
               Delete
            </button>
        </form>
        <button style="display: inline-block" type="submit" class="btn btn-danger">
        <a href="<?php echo e(action([App\Http\Controllers\UserController::class, 'edit'], ['user' => $user])); ?> " class="text-dark">Update</a>
        </button>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abduvali/laravel/lessons/HW_46/resources/views/actions/show.blade.php ENDPATH**/ ?>